
function pares(){
    let i;
    let resultado=document.getElementById("pares");
    resultado.innerHTML =" ";
    for(i=2;i<=100;i+=2){
        //a la variable se le asigna el valor
    resultado.innerHTML += i +"<br>";
    }

    
}