function envio(){
return confirm('Estas seguro de enviar los datos?');
}

function limpia(){
    return confirm('Estas seguro de limpiar los datos?');
}